// Copyright 2020 RT Corporation
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Reference:
// https://github.com/ros-planning/moveit2/blob/main/moveit_demo_nodes
// /run_move_group/src/run_move_group.cpp

#include <cmath>
#include <vector>
#include <iostream>
#include <iomanip>
#include <chrono>
#include <thread>

#include "geometry_msgs/msg/pose.hpp"
#include "geometry_msgs/msg/quaternion.hpp"
#include "moveit/move_group_interface/move_group_interface.h"
#include "rclcpp/rclcpp.hpp"
#include "tf2_geometry_msgs/tf2_geometry_msgs.hpp"

using MoveGroupInterface = moveit::planning_interface::MoveGroupInterface;

static const rclcpp::Logger LOGGER = rclcpp::get_logger("pick_and_place");

double to_radians(const double deg_angle)
{
  return deg_angle * M_PI / 180.0;
}

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions node_options;
  node_options.automatically_declare_parameters_from_overrides(true);
  auto move_group_arm_node = rclcpp::Node::make_shared("move_group_arm_node", node_options);
  auto move_group_gripper_node = rclcpp::Node::make_shared("move_group_gripper_node", node_options);
  const double gx = move_group_arm_node->get_parameter("goal_x").as_double();
  const double gy = move_group_arm_node->get_parameter("goal_y").as_double();
  const double yaw = std::atan2(gy,gx);
  const double radius = std::hypot(gx,gy);
  auto mark = [&](int stage) {
    std::cout << "XY_STAGE " << stage << " " << std::setprecision(15)
              << move_group_arm_node->now().seconds() << std::endl;
  };
  // For current state monitor
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(move_group_arm_node);
  executor.add_node(move_group_gripper_node);
  std::thread([&executor]() {executor.spin();}).detach();

  MoveGroupInterface move_group_arm(move_group_arm_node, "arm");
  move_group_arm.setMaxVelocityScalingFactor(0.5);  // Set 0.0 ~ 1.0
  move_group_arm.setMaxAccelerationScalingFactor(0.5);  // Set 0.0 ~ 1.0

  MoveGroupInterface move_group_gripper(move_group_gripper_node, "gripper");
  move_group_gripper.setMaxVelocityScalingFactor(0.5);  // Set 0.0 ~ 1.0
  move_group_gripper.setMaxAccelerationScalingFactor(0.5);  // Set 0.0 ~ 1.0
  auto gripper_joint_values = move_group_gripper.getCurrentJointValues();
  double GRIPPER_DEFAULT = 0.0;
  double GRIPPER_OPEN = to_radians(-30);
  double GRIPPER_CLOSE = to_radians(10);

  move_group_arm.setNamedTarget("vertical");
  move_group_arm.move();
  mark(1);

  gripper_joint_values[0] = GRIPPER_DEFAULT;
  move_group_gripper.setJointValueTarget(gripper_joint_values);
  move_group_gripper.move();
  mark(2);

  // ----- Picking Preparation -----
  move_group_arm.setNamedTarget("home");
  move_group_arm.move();
  mark(3);

  gripper_joint_values[0] = GRIPPER_OPEN;
  move_group_gripper.setJointValueTarget(gripper_joint_values);
  move_group_gripper.move();
  mark(4);

  geometry_msgs::msg::Pose target_pose;
  tf2::Quaternion q;
  target_pose.position.x = 0.0;
  target_pose.position.y = -0.09;
  target_pose.position.z = 0.17;
  q.setRPY(to_radians(0), to_radians(90), to_radians(-90));
  target_pose.orientation = tf2::toMsg(q);
  move_group_arm.setJointValueTarget(std::vector<double>{-1.5708954173801943, -0.026633053341046882, -1.4293719663001527, -0.16852805064428242});
  move_group_arm.move();
  mark(5);

  q.setRPY(to_radians(0), to_radians(180), to_radians(-90));
  target_pose.orientation = tf2::toMsg(q);
  move_group_arm.setPoseTarget(target_pose);
  move_group_arm.move();
  mark(6);

  target_pose.position.z = 0.14;
  move_group_arm.setPoseTarget(target_pose);
  move_group_arm.move();
  mark(7);

  // Grasp
  gripper_joint_values[0] = GRIPPER_CLOSE;
  move_group_gripper.setJointValueTarget(gripper_joint_values);
  move_group_gripper.move();
  mark(8);

  target_pose.position.z = 0.17;
  move_group_arm.setPoseTarget(target_pose);
  move_group_arm.move();
  mark(9);

  // ----- Placing Preparation -----
  move_group_arm.setNamedTarget("home");
  move_group_arm.move();
  mark(10);

  target_pose.position.x = (radius - 0.10) * std::cos(yaw);
  target_pose.position.y = (radius - 0.10) * std::sin(yaw);
  target_pose.position.z = 0.06;
  q.setRPY(to_radians(0), to_radians(90), yaw);
  target_pose.orientation = tf2::toMsg(q);
  move_group_arm.setPoseTarget(target_pose);
  move_group_arm.move();
  mark(11);

  std::this_thread::sleep_for(std::chrono::milliseconds(1000));

  // Release
  gripper_joint_values[0] = GRIPPER_OPEN;
  move_group_gripper.setJointValueTarget(gripper_joint_values);
  move_group_gripper.move();
  mark(12);

  // Return to home and vertical pose
  move_group_arm.setNamedTarget("home");
  move_group_arm.move();
  mark(13);
  move_group_arm.setNamedTarget("vertical");
  move_group_arm.move();
  mark(14);

  gripper_joint_values[0] = GRIPPER_DEFAULT;
  move_group_gripper.setJointValueTarget(gripper_joint_values);
  move_group_gripper.move();
  mark(15);

  rclcpp::shutdown();
  return 0;
}
